package com.example.quicktax

import android.app.Dialog
import android.os.Bundle
import androidx.fragment.app.DialogFragment
import androidx.appcompat.app.AlertDialog
import android.widget.TextView

class ResultDialogFragment : DialogFragment() {

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val builder = AlertDialog.Builder(requireActivity())
        val inflater = requireActivity().layoutInflater
        val view = inflater.inflate(R.layout.fragment_dialog, null)

        val resultText = view.findViewById<TextView>(R.id.resultText)
        val result = arguments?.getString("result")
        resultText.text = result

        builder.setView(view)
            .setPositiveButton("OK") { dialog, _ -> dialog.dismiss() }

        return builder.create()
    }

    companion object {
        fun newInstance(result: String): ResultDialogFragment {
            val fragment = ResultDialogFragment()
            val args = Bundle()
            args.putString("result", result)
            fragment.arguments = args
            return fragment
        }
    }
}
