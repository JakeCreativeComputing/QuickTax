package com.example.quicktax

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val incomeInput = findViewById<EditText>(R.id.incomeInput)
        val countrySpinner = findViewById<Spinner>(R.id.countrySpinner)
        val calculateButton = findViewById<Button>(R.id.calculateButton)

        val countries = arrayOf(
            "UAE - 5%",
            "USA - 10%",
            "UK - 20%",
            "Canada - 15%",
            "Australia - 18%",
            "Germany - 19%",
            "France - 25%",
            "Japan - 10%",
            "India - 30%",
            "China - 25%",
            "Brazil - 27.5%",
            "Russia - 13%",
            "Italy - 24%",
            "South Africa - 28%",
            "New Zealand - 17.5%",
            "Mexico - 30%",
            "Spain - 21%",
            "Netherlands - 25%",
            "Sweden - 22%",
            "Norway - 22%",
            "Switzerland - 11.5%"
        )

        val taxRates = arrayOf(
            5.0,   // UAE
            10.0,  // USA
            20.0,  // UK
            15.0,  // Canada
            18.0,  // Australia
            19.0,  // Germany
            25.0,  // France
            10.0,  // Japan
            30.0,  // India
            25.0,  // China
            27.5,  // Brazil
            13.0,  // Russia
            24.0,  // Italy
            28.0,  // South Africa
            17.5,  // New Zealand
            30.0,  // Mexico
            21.0,  // Spain
            25.0,  // Netherlands
            22.0,  // Sweden
            22.0,  // Norway
            11.5   // Switzerland
        )

        val adapter = ArrayAdapter(
            this,
            R.layout.spinner_design,
            countries
        )
        adapter.setDropDownViewResource(R.layout.spinner_design)
        countrySpinner.adapter = adapter

        calculateButton.setOnClickListener {
            val incomeStr = incomeInput.text.toString()
            val selectedCountryIndex = countrySpinner.selectedItemPosition
            val taxRate = taxRates[selectedCountryIndex]

            if (incomeStr.isNotEmpty()) {
                val income = incomeStr.toDouble()

                val taxAmount = income * (taxRate / 100)
                val totalAmount = income + taxAmount

                val result = String.format(
                    "Price: %.2f\nTax Amount: %.2f\nTotal After Tax: %.2f",
                    income, taxAmount, totalAmount
                )

                val dialog = ResultDialogFragment.newInstance(result)
                dialog.show(supportFragmentManager, "ResultDialog")
            }
        }
    }
}
